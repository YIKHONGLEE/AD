﻿using System.Linq;
using System.Web.Mvc;
using MVC_1.Models;

namespace MVC_1.Controllers
{
    public class LoginController : Controller
    {
        lindaaEntities db = new lindaaEntities();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Index(Models.user objchk)
        {

            if(ModelState.IsValid)
            {
                using (lindaaEntities db = new lindaaEntities())
                {
                    var obj = db.users.Where(a => a.username.Equals(objchk.username) && a.password.Equals(objchk.password)).FirstOrDefault();

                    if (obj != null)
                    {
                        Session["UserID"] = obj.id.ToString();
                        Session["UserName"] = obj.id.ToString();
                        return RedirectToAction("Index", "Home");

                    }

                    else
                    {
                        ModelState.AddModelError("", "The UserName or Password Incorrect");

                    }
                }
            }


                return View(objchk);
        }
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Index", "Login");
        }

    }
}